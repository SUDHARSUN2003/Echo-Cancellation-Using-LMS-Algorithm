This disk contains 36 m-files that are used

in the textbook



	Monson H. Hayes,

	"Statistical Digital Signal Processing and Modeling"

	John Wiley & Sons, 1996



A detailed description of how to use these m-files may be

found in the Appendix of the textbook.



NOTE:  In order to conform to the 8 character limit on 

       mfiles, the following file names have been changed:



       periodogram.m ->  per.m

       per_smooth.m  -> sper.m



These M-files are User Contributed Routines which are being redistributed by The MathWorks, upon request, on an "as is" basis.  A User Contributed Routine is not a product of The MathWorks, Inc. and The MathWorks assumes no responsibility for any errors that may exist in these routines.



M. Hayes

Professor of Electrical and Computer Engineering

Georgia Tech, School of ECE, 

Atlanta, GA  30332-0250

mhh3@eedsp.gatech.edu



